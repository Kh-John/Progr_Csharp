﻿int x = 5;
int y = -3;

if (x > 0 & y > 0)

{
    System.Console.WriteLine("1");
}

if (x < 0 & y > 0)

{
    System.Console.WriteLine("2");
}

if (x < 0 & y < 0)

{
    System.Console.WriteLine("3");
}

if (x > 0 & y < 0)
{
    System.Console.WriteLine("4");
}
else
{
    System.Console.WriteLine("Одна из координат равна нулю!");
}



