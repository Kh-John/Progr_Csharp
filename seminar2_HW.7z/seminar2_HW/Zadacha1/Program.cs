﻿int a = 161;
if (a % 7 == 0 && a % 23 == 0)
{
    System.Console.WriteLine("да");
}
else
{
    System.Console.WriteLine("нет");
}